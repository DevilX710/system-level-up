/* =========================================================
   RENDER — one function per feature area
   ========================================================= */

function renderAll() {
  renderProfile();
  renderStreak();
  renderQuests();
  renderStats();
  renderGoals();
  renderNotes();
  renderReminders();
  renderBudget();
  renderAnalytics();
  renderAchievements();
  renderSkillTree();
  renderCalendar();
  renderSettings();
}

/* ---------- profile / dashboard ---------- */
function renderProfile() {
  document.getElementById("avatarEmoji").textContent = state.profile.avatar;
  document.getElementById("profileName").textContent = state.profile.name;
  document.getElementById("profileRank").textContent =
    `${rankForLevel(state.profile.level)} · Lv ${state.profile.level}`;

  const needed = xpNeededForLevel(state.profile.level);
  document.getElementById("xpCurrent").textContent = state.profile.xp;
  document.getElementById("xpNeeded").textContent = needed;
  document.getElementById("xpBarFill").style.width =
    `${Math.min(100, (state.profile.xp / needed) * 100)}%`;

  const settingsName = document.getElementById("settingsNameInput");
  if (settingsName) settingsName.value = state.profile.name;
}

function renderStreak() {
  document.getElementById("streakCount").textContent = state.streak.current;
  const shieldEl = document.getElementById("streakShieldStatus");
  if (shieldEl) {
    shieldEl.textContent = state.streak.shieldAvailable ? "🛡️ Shield ready" : "🛡️ Shield used this month";
  }
}

function renderQuests() {
  const list = document.getElementById("questList");
  const empty = document.getElementById("questEmpty");
  list.innerHTML = "";

  if (state.quests.length === 0) {
    empty.classList.remove("hidden");
    return;
  }
  empty.classList.add("hidden");

  for (const q of state.quests) {
    const item = document.createElement("div");
    item.className = "quest-item" + (q.done ? " done" : "");
    item.innerHTML = `
      <div class="quest-check ${q.done ? "checked" : ""}" data-id="${q.id}">${q.done ? "✓" : ""}</div>
      <div class="quest-title">${escapeHtml(q.title)}${q.skill ? `<span class="quest-skill-tag">${q.skill}</span>` : ""}</div>
      <div class="quest-xp">+${q.xp}xp</div>
      <div class="quest-del" data-del="${q.id}">✕</div>
    `;
    list.appendChild(item);
  }
  list.querySelectorAll(".quest-check").forEach(el =>
    el.addEventListener("click", () => toggleQuest(el.dataset.id)));
  list.querySelectorAll(".quest-del").forEach(el =>
    el.addEventListener("click", (e) => { e.stopPropagation(); deleteQuest(el.dataset.del); }));
}

function renderStats() {
  const doneToday = state.quests.filter(q => q.done).length;
  document.getElementById("statCompletedToday").textContent = doneToday;
  document.getElementById("statBestStreak").textContent = state.streak.best;
  document.getElementById("statTotalXP").textContent = state.profile.totalXP;
  document.getElementById("statLevel").textContent = state.profile.level;
}

/* ---------- goals ---------- */
function renderGoals() {
  const wrap = document.getElementById("goalsList");
  if (!wrap) return;
  wrap.innerHTML = "";
  if (state.goals.length === 0) {
    wrap.innerHTML = `<div class="empty-state">No goals yet. Set your sights on something big.</div>`;
    return;
  }
  for (const g of state.goals) {
    const d = daysUntil(g.deadline);
    const deadlineText = g.deadline ? (d >= 0 ? `${d}d left` : `overdue`) : "no deadline";
    const card = document.createElement("div");
    card.className = "goal-card";
    card.innerHTML = `
      <div class="goal-top">
        <div class="goal-title">${escapeHtml(g.title)}</div>
        <div class="goal-del" data-del="${g.id}">✕</div>
      </div>
      <div class="goal-progress-track"><div class="goal-progress-fill" style="width:${g.progress}%"></div></div>
      <div class="goal-meta">${g.progress}% · ${deadlineText}</div>
      <div class="milestone-list">
        ${g.milestones.map(m => `
          <div class="milestone-item">
            <div class="milestone-check ${m.done ? "checked" : ""}" data-goal="${g.id}" data-ms="${m.id}">${m.done ? "✓" : ""}</div>
            <div class="milestone-title ${m.done ? "done" : ""}">${escapeHtml(m.title)}</div>
          </div>`).join("")}
      </div>
      <div class="goal-actions">
        <button class="btn-mini" data-add-ms="${g.id}">+ Milestone</button>
        <button class="btn-mini" data-convert="${g.id}">→ Quest</button>
      </div>
    `;
    wrap.appendChild(card);
  }
  wrap.querySelectorAll(".goal-del").forEach(el =>
    el.addEventListener("click", () => deleteGoal(el.dataset.del)));
  wrap.querySelectorAll(".milestone-check").forEach(el =>
    el.addEventListener("click", () => toggleMilestone(el.dataset.goal, el.dataset.ms)));
  wrap.querySelectorAll("[data-add-ms]").forEach(el =>
    el.addEventListener("click", () => {
      const title = prompt("Milestone name:");
      if (title && title.trim()) addMilestone(el.dataset.addMs, title.trim());
    }));
  wrap.querySelectorAll("[data-convert]").forEach(el =>
    el.addEventListener("click", () => convertGoalToQuest(el.dataset.convert)));
}

/* ---------- notes ---------- */
function renderNotes(query = "") {
  const wrap = document.getElementById("notesList");
  if (!wrap) return;
  const list = searchNotes(query);
  wrap.innerHTML = "";
  if (list.length === 0) {
    wrap.innerHTML = `<div class="empty-state">No notes found.</div>`;
    return;
  }
  for (const n of list) {
    const card = document.createElement("div");
    card.className = "note-card" + (n.pinned ? " pinned" : "");
    card.innerHTML = `
      <div class="note-top">
        <div class="note-title">${n.pinned ? "📌 " : ""}${escapeHtml(n.title)}</div>
        <div class="note-actions">
          <span class="note-pin" data-pin="${n.id}">${n.pinned ? "Unpin" : "Pin"}</span>
          <span class="note-del" data-del="${n.id}">✕</span>
        </div>
      </div>
      <div class="note-body">${escapeHtml(n.body).slice(0,140)}${n.body.length > 140 ? "…" : ""}</div>
    `;
    card.addEventListener("click", (e) => {
      if (e.target.closest(".note-pin") || e.target.closest(".note-del")) return;
      openNoteEditor(n.id);
    });
    wrap.appendChild(card);
  }
  wrap.querySelectorAll(".note-pin").forEach(el =>
    el.addEventListener("click", () => togglePinNote(el.dataset.pin)));
  wrap.querySelectorAll(".note-del").forEach(el =>
    el.addEventListener("click", () => deleteNote(el.dataset.del)));
}

/* ---------- reminders ---------- */
function renderReminders() {
  const wrap = document.getElementById("remindersList");
  if (!wrap) return;
  const list = upcomingReminders();
  wrap.innerHTML = "";
  if (list.length === 0) {
    wrap.innerHTML = `<div class="empty-state">No upcoming reminders.</div>`;
    return;
  }
  for (const r of list) {
    const dt = new Date(r.datetime);
    const row = document.createElement("div");
    row.className = "reminder-item";
    row.innerHTML = `
      <div class="reminder-check" data-id="${r.id}"></div>
      <div class="reminder-info">
        <div class="reminder-title">${escapeHtml(r.title)}</div>
        <div class="reminder-time">${dt.toLocaleString([], {month:"short",day:"numeric",hour:"2-digit",minute:"2-digit"})}${r.repeat !== "none" ? ` · ${r.repeat}` : ""}</div>
      </div>
      <div class="reminder-del" data-del="${r.id}">✕</div>
    `;
    wrap.appendChild(row);
  }
  wrap.querySelectorAll(".reminder-check").forEach(el =>
    el.addEventListener("click", () => toggleReminderDone(el.dataset.id)));
  wrap.querySelectorAll(".reminder-del").forEach(el =>
    el.addEventListener("click", () => deleteReminder(el.dataset.del)));
}

/* ---------- budget ---------- */
function renderBudget() {
  const balEl = document.getElementById("budgetBalance");
  if (!balEl) return;
  const balance = getBalance();
  balEl.textContent = balance.toFixed(2);
  balEl.className = balance >= 0 ? "budget-balance positive" : "budget-balance negative";

  const summary = getMonthSummary();
  document.getElementById("budgetIncome").textContent = summary.income.toFixed(2);
  document.getElementById("budgetExpense").textContent = summary.expense.toFixed(2);

  const catWrap = document.getElementById("budgetCategories");
  catWrap.innerHTML = "";
  const cats = Object.entries(summary.byCategory).sort((a,b) => b[1]-a[1]);
  if (cats.length === 0) {
    catWrap.innerHTML = `<div class="empty-state">No expenses this month yet.</div>`;
  } else {
    const max = cats[0][1];
    for (const [cat, amt] of cats) {
      const row = document.createElement("div");
      row.className = "cat-row";
      row.innerHTML = `
        <div class="cat-label">${escapeHtml(cat)}</div>
        <div class="cat-bar-track"><div class="cat-bar-fill" style="width:${(amt/max)*100}%"></div></div>
        <div class="cat-amount">${amt.toFixed(0)}</div>`;
      catWrap.appendChild(row);
    }
  }

  const txWrap = document.getElementById("transactionList");
  txWrap.innerHTML = "";
  const recent = [...state.transactions].sort((a,b) => b.date.localeCompare(a.date)).slice(0, 15);
  for (const t of recent) {
    const row = document.createElement("div");
    row.className = "tx-item";
    row.innerHTML = `
      <div class="tx-info">
        <div class="tx-cat">${escapeHtml(t.category)}</div>
        <div class="tx-note">${escapeHtml(t.note || t.date)}</div>
      </div>
      <div class="tx-amount ${t.type}">${t.type === "income" ? "+" : "-"}${t.amount.toFixed(2)}</div>
      <div class="tx-del" data-del="${t.id}">✕</div>
    `;
    txWrap.appendChild(row);
  }
  txWrap.querySelectorAll(".tx-del").forEach(el =>
    el.addEventListener("click", () => deleteTransaction(el.dataset.del)));

  const savWrap = document.getElementById("savingGoalsList");
  savWrap.innerHTML = "";
  if (state.savingGoals.length === 0) {
    savWrap.innerHTML = `<div class="empty-state">No saving goals yet.</div>`;
  }
  for (const g of state.savingGoals) {
    const pct = g.target > 0 ? Math.min(100, (g.saved / g.target) * 100) : 0;
    const row = document.createElement("div");
    row.className = "saving-goal";
    row.innerHTML = `
      <div class="goal-top">
        <div class="goal-title">${escapeHtml(g.title)}</div>
        <div class="goal-del" data-del="${g.id}">✕</div>
      </div>
      <div class="goal-progress-track"><div class="goal-progress-fill gold" style="width:${pct}%"></div></div>
      <div class="goal-meta">${g.saved.toFixed(0)} / ${g.target.toFixed(0)}</div>
      <div class="goal-actions">
        <button class="btn-mini" data-add="${g.id}">+ Add funds</button>
      </div>
    `;
    savWrap.appendChild(row);
  }
  savWrap.querySelectorAll("[data-del]").forEach(el =>
    el.addEventListener("click", () => deleteSavingGoal(el.dataset.del)));
  savWrap.querySelectorAll("[data-add]").forEach(el =>
    el.addEventListener("click", () => {
      const amt = prompt("Amount to add:");
      if (amt && !isNaN(parseFloat(amt))) addToSavingGoal(el.dataset.add, parseFloat(amt));
    }));
}

/* ---------- analytics ---------- */
function renderAnalytics() {
  const wrap = document.getElementById("xpChartBars");
  if (!wrap) return;
  const data = xpByDay(14);
  const max = Math.max(1, ...data.map(d => d.xp));
  wrap.innerHTML = data.map(d => `
    <div class="chart-bar-col">
      <div class="chart-bar" style="height:${(d.xp/max)*100}%"></div>
      <div class="chart-bar-label">${d.date.slice(8,10)}</div>
    </div>
  `).join("");

  document.getElementById("analyticsCompletionRate").textContent = questCompletionRate(7) + "%";
  document.getElementById("analyticsWeeklySpend").textContent = weeklySpending().toFixed(0);
  document.getElementById("analyticsTotalXP").textContent = state.profile.totalXP;
  document.getElementById("analyticsQuestsLogged").textContent = state.xpHistory.filter(h=>h.amount>0).length;
}

/* ---------- achievements ---------- */
function renderAchievements() {
  const wrap = document.getElementById("achievementsGrid");
  if (!wrap) return;
  wrap.innerHTML = "";
  for (const def of ACHIEVEMENT_DEFS) {
    const unlocked = !!state.achievements[def.id];
    const showSecret = def.secret && !unlocked;
    const card = document.createElement("div");
    card.className = "ach-card" + (unlocked ? " unlocked" : "");
    card.innerHTML = `
      <div class="ach-icon">${unlocked ? "👑" : "🔒"}</div>
      <div class="ach-name">${showSecret ? "???" : escapeHtml(def.name)}</div>
      <div class="ach-desc">${showSecret ? "Secret achievement" : escapeHtml(def.desc)}</div>
    `;
    wrap.appendChild(card);
  }
}

/* ---------- skill tree ---------- */
function renderSkillTree() {
  const wrap = document.getElementById("skillTreeGrid");
  if (!wrap) return;
  wrap.innerHTML = "";
  const skills = allSkills();
  const max = Math.max(50, ...skills.map(s => state.skillXP[s] || 0));
  for (const s of skills) {
    const val = state.skillXP[s] || 0;
    const pct = Math.min(100, (val / max) * 100);
    const node = document.createElement("div");
    node.className = "skill-node";
    node.innerHTML = `
      <div class="skill-ring">
        <svg viewBox="0 0 60 60">
          <circle cx="30" cy="30" r="26" class="skill-ring-bg"/>
          <circle cx="30" cy="30" r="26" class="skill-ring-fill" style="stroke-dasharray:${2*Math.PI*26}; stroke-dashoffset:${2*Math.PI*26*(1-pct/100)}"/>
        </svg>
        <div class="skill-ring-label">${val}</div>
      </div>
      <div class="skill-name">${escapeHtml(s)}</div>
    `;
    wrap.appendChild(node);
  }
}

/* ---------- calendar ---------- */
let calendarViewDate = new Date();
function renderCalendar() {
  const grid = document.getElementById("calendarGrid");
  if (!grid) return;
  const y = calendarViewDate.getFullYear(), m = calendarViewDate.getMonth();
  document.getElementById("calendarLabel").textContent =
    calendarViewDate.toLocaleString([], { month: "long", year: "numeric" });

  const firstDayIdx = new Date(y, m, 1).getDay();
  const totalDays = daysInMonth(y, m);
  grid.innerHTML = "";

  for (let i = 0; i < firstDayIdx; i++) {
    grid.appendChild(document.createElement("div"));
  }
  for (let day = 1; day <= totalDays; day++) {
    const dateStr = `${y}-${String(m+1).padStart(2,"0")}-${String(day).padStart(2,"0")}`;
    const ev = eventsForDate(dateStr);
    const cell = document.createElement("div");
    cell.className = "cal-cell" + (dateStr === todayStr() ? " today" : "") + (ev.completed ? " completed" : "");
    const hasEvents = ev.quests.length || ev.reminders.length || ev.goalsDue.length;
    cell.innerHTML = `<div class="cal-day">${day}</div>${hasEvents ? `<div class="cal-dot"></div>` : ""}`;
    cell.addEventListener("click", () => showDayDetail(dateStr, ev));
    grid.appendChild(cell);
  }
}

function showDayDetail(dateStr, ev) {
  const parts = [];
  if (ev.quests.length) parts.push(`${ev.quests.length} quest(s)`);
  if (ev.reminders.length) parts.push(`${ev.reminders.length} reminder(s)`);
  if (ev.goalsDue.length) parts.push(`${ev.goalsDue.length} goal deadline(s)`);
  notify(dateStr, parts.length ? parts.join(", ") : "No events");
}

/* ---------- settings ---------- */
function renderSettings() {
  const sound = document.getElementById("settingSound");
  const anim = document.getElementById("settingAnimations");
  const theme = document.getElementById("settingTheme");
  if (sound) sound.checked = state.settings.sound;
  if (anim) anim.checked = state.settings.animations;
  if (theme) theme.value = state.settings.theme;
  document.body.classList.toggle("light-theme", state.settings.theme === "light");
  document.body.classList.toggle("no-anim", !state.settings.animations);
}

/* ---------- tab switching ---------- */
function switchTab(tabName) {
  document.querySelectorAll(".tab-panel").forEach(el => el.classList.add("hidden"));
  const target = document.getElementById("tab-" + tabName);
  if (target) target.classList.remove("hidden");
  document.querySelectorAll(".nav-item").forEach(el =>
    el.classList.toggle("active", el.dataset.tab === tabName));
  // re-render the panel being shown so it reflects latest state
  const renderers = {
    home: renderAll, goals: renderGoals, calendar: renderCalendar,
    notes: () => renderNotes(document.getElementById("noteSearchInput")?.value || ""),
    budget: renderBudget, analytics: renderAnalytics, achievements: renderAchievements,
    skills: renderSkillTree, settings: renderSettings, reminders: renderReminders,
  };
  if (renderers[tabName]) renderers[tabName]();
}
