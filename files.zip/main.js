/* =========================================================
   MODALS + EVENT WIRING + BOOT
   ========================================================= */

/* ---------- note editor ---------- */
let editingNoteId = null;
function openNoteEditor(id) {
  editingNoteId = id;
  const n = id ? state.notes.find(n => n.id === id) : null;
  document.getElementById("noteEditorTitle").value = n ? n.title : "";
  document.getElementById("noteEditorBody").value = n ? n.body : "";
  document.getElementById("noteEditorModal").classList.remove("hidden");
}
function closeNoteEditor() {
  document.getElementById("noteEditorModal").classList.add("hidden");
  editingNoteId = null;
}

/* ---------- generic modal open/close ---------- */
function openModal(id) { document.getElementById(id).classList.remove("hidden"); }
function closeModal(id) { document.getElementById(id).classList.add("hidden"); }

/* ---------- wire everything on DOM ready ---------- */
function wireUI() {
  // level up close
  document.getElementById("levelUpClose").addEventListener("click", () => {
    const overlay = document.getElementById("levelUpOverlay");
    overlay.classList.remove("visible");
    setTimeout(() => overlay.classList.add("hidden"), 300);
  });

  // bottom nav tabs
  document.querySelectorAll(".nav-item[data-tab]").forEach(el => {
    el.addEventListener("click", () => switchTab(el.dataset.tab));
  });

  // ---- Add Quest modal ----
  let selectedXP = 25, selectedSkill = null;
  document.getElementById("openAddQuest").addEventListener("click", () => {
    document.getElementById("questTitleInput").value = "";
    openModal("addQuestModal");
  });
  document.getElementById("cancelAddQuest").addEventListener("click", () => closeModal("addQuestModal"));
  document.querySelectorAll(".diff-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".diff-btn").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      selectedXP = parseInt(btn.dataset.xp, 10);
    });
  });
  const questSkillSelect = document.getElementById("questSkillSelect");
  if (questSkillSelect) {
    allSkills().forEach(s => {
      const opt = document.createElement("option");
      opt.value = s; opt.textContent = s;
      questSkillSelect.appendChild(opt);
    });
  }
  document.getElementById("confirmAddQuest").addEventListener("click", () => {
    const title = document.getElementById("questTitleInput").value.trim();
    if (!title) return;
    const skill = questSkillSelect ? questSkillSelect.value : null;
    addQuest(title, selectedXP, skill || null);
    closeModal("addQuestModal");
  });

  // ---- Goals ----
  document.getElementById("openAddGoal")?.addEventListener("click", () => {
    document.getElementById("goalTitleInput").value = "";
    document.getElementById("goalDeadlineInput").value = "";
    openModal("addGoalModal");
  });
  document.getElementById("cancelAddGoal")?.addEventListener("click", () => closeModal("addGoalModal"));
  document.getElementById("confirmAddGoal")?.addEventListener("click", () => {
    const title = document.getElementById("goalTitleInput").value.trim();
    if (!title) return;
    addGoal(title, document.getElementById("goalDeadlineInput").value || null);
    closeModal("addGoalModal");
  });

  // ---- Notes ----
  document.getElementById("openAddNote")?.addEventListener("click", () => openNoteEditor(null));
  document.getElementById("cancelNoteEdit")?.addEventListener("click", closeNoteEditor);
  document.getElementById("saveNoteEdit")?.addEventListener("click", () => {
    const title = document.getElementById("noteEditorTitle").value.trim() || "Untitled";
    const body = document.getElementById("noteEditorBody").value;
    if (editingNoteId) updateNote(editingNoteId, title, body);
    else addNote(title, body);
    closeNoteEditor();
  });
  document.getElementById("noteSearchInput")?.addEventListener("input", (e) => renderNotes(e.target.value));

  // ---- Reminders ----
  document.getElementById("openAddReminder")?.addEventListener("click", () => {
    document.getElementById("reminderTitleInput").value = "";
    const now = new Date(Date.now() + 3600000);
    document.getElementById("reminderDatetimeInput").value = now.toISOString().slice(0,16);
    openModal("addReminderModal");
  });
  document.getElementById("cancelAddReminder")?.addEventListener("click", () => closeModal("addReminderModal"));
  document.getElementById("confirmAddReminder")?.addEventListener("click", () => {
    const title = document.getElementById("reminderTitleInput").value.trim();
    const dt = document.getElementById("reminderDatetimeInput").value;
    if (!title || !dt) return;
    const repeat = document.getElementById("reminderRepeatSelect").value;
    addReminder(title, dt, repeat);
    closeModal("addReminderModal");
  });

  // ---- Budget ----
  document.getElementById("openAddTransaction")?.addEventListener("click", () => {
    document.getElementById("txAmountInput").value = "";
    document.getElementById("txNoteInput").value = "";
    populateTxCategories("expense");
    document.querySelectorAll(".tx-type-btn").forEach(b => b.classList.remove("active"));
    document.querySelector('.tx-type-btn[data-type="expense"]').classList.add("active");
    openModal("addTransactionModal");
  });
  document.querySelectorAll(".tx-type-btn").forEach(btn => {
    btn.addEventListener("click", () => {
      document.querySelectorAll(".tx-type-btn").forEach(b => b.classList.remove("active"));
      btn.classList.add("active");
      populateTxCategories(btn.dataset.type);
    });
  });
  document.getElementById("cancelAddTransaction")?.addEventListener("click", () => closeModal("addTransactionModal"));
  document.getElementById("confirmAddTransaction")?.addEventListener("click", () => {
    const amt = parseFloat(document.getElementById("txAmountInput").value);
    if (isNaN(amt) || amt <= 0) return;
    const type = document.querySelector(".tx-type-btn.active").dataset.type;
    const category = document.getElementById("txCategorySelect").value;
    const note = document.getElementById("txNoteInput").value.trim();
    addTransaction(type, amt, category, note);
    closeModal("addTransactionModal");
  });

  document.getElementById("openAddSavingGoal")?.addEventListener("click", () => {
    const title = prompt("Saving goal name:");
    if (!title) return;
    const target = prompt("Target amount:");
    addSavingGoal(title, parseFloat(target) || 0);
  });

  // ---- Quick Add (floating action) ----
  document.getElementById("quickAddBtn")?.addEventListener("click", () => openModal("quickAddModal"));
  document.getElementById("closeQuickAdd")?.addEventListener("click", () => closeModal("quickAddModal"));
  document.querySelectorAll(".quick-add-option").forEach(el => {
    el.addEventListener("click", () => {
      closeModal("quickAddModal");
      const type = el.dataset.type;
      if (type === "quest") { switchTab("home"); document.getElementById("openAddQuest").click(); }
      if (type === "goal") { switchTab("goals"); document.getElementById("openAddGoal").click(); }
      if (type === "note") { switchTab("notes"); openNoteEditor(null); }
      if (type === "expense") { switchTab("budget"); document.getElementById("openAddTransaction").click(); }
      if (type === "reminder") { switchTab("reminders"); document.getElementById("openAddReminder").click(); }
    });
  });

  // ---- Rewards ----
  document.getElementById("claimDailyBonusBtn")?.addEventListener("click", claimDailyBonus);

  // ---- Calendar nav ----
  document.getElementById("calPrev")?.addEventListener("click", () => {
    calendarViewDate.setMonth(calendarViewDate.getMonth() - 1);
    renderCalendar();
  });
  document.getElementById("calNext")?.addEventListener("click", () => {
    calendarViewDate.setMonth(calendarViewDate.getMonth() + 1);
    renderCalendar();
  });

  // ---- Settings ----
  document.getElementById("settingsNameInput")?.addEventListener("change", (e) => {
    state.profile.name = e.target.value.trim() || "Player";
    save(); renderProfile();
  });
  document.getElementById("settingSound")?.addEventListener("change", (e) => {
    state.settings.sound = e.target.checked; save();
  });
  document.getElementById("settingAnimations")?.addEventListener("change", (e) => {
    state.settings.animations = e.target.checked; save(); renderSettings();
  });
  document.getElementById("settingTheme")?.addEventListener("change", (e) => {
    state.settings.theme = e.target.value; save(); renderSettings();
  });
  document.getElementById("exportBtn")?.addEventListener("click", exportData);
  document.getElementById("importBtn")?.addEventListener("click", () => document.getElementById("importFileInput").click());
  document.getElementById("importFileInput")?.addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (file) importData(file, () => renderAll());
  });
  document.getElementById("resetDataBtn")?.addEventListener("click", () => {
    if (confirm("This will permanently erase all your data. Are you sure?")) {
      resetAllData();
      renderAll();
    }
  });

  // avatar picker (simple emoji cycle)
  document.getElementById("avatarEmoji")?.addEventListener("click", () => {
    const options = ["🗡️","🛡️","🏹","🔮","⚡","🐉","👑","🦁"];
    const idx = options.indexOf(state.profile.avatar);
    state.profile.avatar = options[(idx + 1) % options.length];
    save(); renderProfile();
  });
}

function populateTxCategories(type) {
  const sel = document.getElementById("txCategorySelect");
  sel.innerHTML = "";
  const cats = type === "income" ? INCOME_CATEGORIES : EXPENSE_CATEGORIES;
  cats.forEach(c => {
    const opt = document.createElement("option");
    opt.value = c; opt.textContent = c;
    sel.appendChild(opt);
  });
}

/* ---------- boot ---------- */
function boot() {
  checkDailyReset();
  wireUI();
  renderAll();
  checkAchievements();
}
document.addEventListener("DOMContentLoaded", boot);
