/* =========================================================
   GOALS
   ========================================================= */

function addGoal(title, deadline) {
  state.goals.push({
    id: uid(), title, deadline: deadline || null,
    progress: 0, milestones: [], createdAt: todayStr(),
  });
  save();
  renderGoals();
}

function deleteGoal(id) {
  state.goals = state.goals.filter(g => g.id !== id);
  save();
  renderGoals();
}

function addMilestone(goalId, title) {
  const g = state.goals.find(g => g.id === goalId);
  if (!g) return;
  g.milestones.push({ id: uid(), title, done: false });
  recalcGoalProgress(g);
  save();
  renderGoals();
}

function toggleMilestone(goalId, milestoneId) {
  const g = state.goals.find(g => g.id === goalId);
  if (!g) return;
  const m = g.milestones.find(m => m.id === milestoneId);
  if (!m) return;
  m.done = !m.done;
  const wasComplete = g.progress >= 100;
  recalcGoalProgress(g);
  if (!wasComplete && g.progress >= 100) {
    grantXP(50);
    notify("GOAL COMPLETE", `${g.title} — +50 XP`);
  }
  save();
  renderGoals();
}

function recalcGoalProgress(g) {
  if (g.milestones.length === 0) { g.progress = g.progress || 0; return; }
  const done = g.milestones.filter(m => m.done).length;
  g.progress = Math.round((done / g.milestones.length) * 100);
}

function setGoalProgressManual(goalId, pct) {
  const g = state.goals.find(g => g.id === goalId);
  if (!g) return;
  const wasComplete = g.progress >= 100;
  g.progress = Math.max(0, Math.min(100, pct));
  if (!wasComplete && g.progress >= 100) {
    grantXP(50);
    notify("GOAL COMPLETE", `${g.title} — +50 XP`);
  }
  save();
  renderGoals();
}

function convertGoalToQuest(goalId) {
  const g = state.goals.find(g => g.id === goalId);
  if (!g) return;
  addQuest(`${g.title} (goal step)`, 25, null);
  notify("QUEST SPAWNED", `From goal: ${g.title}`);
}

function daysUntil(dateStr) {
  if (!dateStr) return null;
  const diff = new Date(dateStr) - new Date(todayStr());
  return Math.ceil(diff / 86400000);
}
