/* =========================================================
   CORE — state, persistence, XP engine, notifications
   ========================================================= */

const STORAGE_KEY = "awakening_state_v2";

const RANKS = [
  { min: 1,  title: "Rank E Hunter" },
  { min: 5,  title: "Rank D Hunter" },
  { min: 10, title: "Rank C Hunter" },
  { min: 20, title: "Rank B Hunter" },
  { min: 35, title: "Rank A Hunter" },
  { min: 50, title: "Rank S Hunter" },
  { min: 75, title: "National Level Hunter" },
];

const SKILLS = ["INT", "STR", "DISCIPLINE", "FINANCE"];

function todayStr(offsetDays = 0) {
  const d = new Date();
  d.setDate(d.getDate() + offsetDays);
  return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
}

function uid() {
  return crypto.randomUUID ? crypto.randomUUID() : String(Date.now() + Math.random());
}

function xpNeededForLevel(level) {
  return 100 + (level - 1) * 40;
}

function rankForLevel(level) {
  let r = RANKS[0].title;
  for (const entry of RANKS) if (level >= entry.min) r = entry.title;
  return r;
}

function defaultState() {
  return {
    profile: {
      name: "Player",
      avatar: "🗡️",
      level: 1,
      xp: 0,
      totalXP: 0,
      customSkills: [], // extra skill names beyond the 4 defaults
    },
    settings: {
      theme: "dark",
      sound: true,
      animations: true,
    },
    streak: {
      current: 0,
      best: 0,
      lastCompletionDate: null,
      shieldAvailable: true, // one "miss forgiveness" per month
      shieldUsedDate: null,
    },
    quests: [], // {id,title,xp,done,date,skill}
    goals: [],  // {id,title,deadline,progress,milestones:[{id,title,done}],createdAt}
    notes: [],  // {id,title,body,pinned,updatedAt}
    reminders: [], // {id,title,datetime,repeat,done}
    transactions: [], // {id,type:'income'|'expense',amount,category,note,date}
    savingGoals: [], // {id,title,target,saved}
    skillXP: { INT: 0, STR: 0, DISCIPLINE: 0, FINANCE: 0 }, // + custom skill keys
    achievements: {}, // id -> {unlockedAt}
    xpHistory: [], // {date, amount} per grant, for analytics
    rewardsClaimed: {}, // dailyBonus date-keyed
    lastResetDate: todayStr(),
  };
}

let state = load();

function load() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultState();
    const parsed = JSON.parse(raw);
    const merged = { ...defaultState(), ...parsed };
    // deep-merge nested objects that might be missing new sub-keys
    merged.profile = { ...defaultState().profile, ...parsed.profile };
    merged.settings = { ...defaultState().settings, ...parsed.settings };
    merged.streak = { ...defaultState().streak, ...parsed.streak };
    merged.skillXP = { ...defaultState().skillXP, ...parsed.skillXP };
    return merged;
  } catch (e) {
    console.error("Failed to load state, resetting.", e);
    return defaultState();
  }
}

function save() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

/* ---------- notifications (toast) ---------- */
let notifTimer = null;
function notify(tag, message) {
  const el = document.getElementById("sysNotif");
  if (!el) return;
  el.innerHTML = `<span class="tag">[SYSTEM]</span>${tag} — ${message}`;
  el.classList.add("show");
  clearTimeout(notifTimer);
  notifTimer = setTimeout(() => el.classList.remove("show"), 2600);
  playSound("notif");
}

function playSound(kind) {
  if (!state.settings.sound) return;
  // Lightweight WebAudio beep, no audio files needed (keeps app tiny/offline-safe)
  try {
    const ctx = playSound._ctx || (playSound._ctx = new (window.AudioContext || window.webkitAudioContext)());
    const o = ctx.createOscillator();
    const g = ctx.createGain();
    o.connect(g); g.connect(ctx.destination);
    const freqs = { notif: 660, complete: 880, levelup: 1046, error: 220 };
    o.frequency.value = freqs[kind] || 660;
    g.gain.setValueAtTime(0.06, ctx.currentTime);
    g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.25);
    o.start();
    o.stop(ctx.currentTime + 0.25);
  } catch (e) { /* audio not available, ignore */ }
}

/* ---------- XP / level engine ---------- */
function grantXP(amount, skill = null) {
  state.profile.xp += amount;
  state.profile.totalXP = Math.max(0, state.profile.totalXP + Math.max(0, amount));
  state.xpHistory.push({ date: todayStr(), amount });
  if (skill) {
    state.skillXP[skill] = (state.skillXP[skill] || 0) + Math.max(0, amount);
  }

  let leveledUp = false;
  let needed = xpNeededForLevel(state.profile.level);
  while (state.profile.xp >= needed) {
    state.profile.xp -= needed;
    state.profile.level += 1;
    leveledUp = true;
    needed = xpNeededForLevel(state.profile.level);
  }
  while (state.profile.xp < 0 && state.profile.level > 1) {
    state.profile.level -= 1;
    state.profile.xp += xpNeededForLevel(state.profile.level);
  }
  if (state.profile.xp < 0) state.profile.xp = 0;

  if (leveledUp) {
    showLevelUp();
    playSound("levelup");
  }
  checkAchievements();
  return leveledUp;
}

function showLevelUp() {
  const overlay = document.getElementById("levelUpOverlay");
  if (!overlay) return;
  document.getElementById("levelUpNumber").textContent = state.profile.level;
  document.getElementById("levelUpRank").textContent = rankForLevel(state.profile.level);
  overlay.classList.remove("hidden");
  requestAnimationFrame(() => overlay.classList.add("visible"));
}

/* ---------- daily reset ---------- */
function checkDailyReset() {
  const today = todayStr();
  if (state.lastResetDate !== today) {
    const hadCompletionYesterday = state.streak.lastCompletionDate === state.lastResetDate;
    const questsExistedYesterday = state.quests.length > 0;

    if (!hadCompletionYesterday && questsExistedYesterday) {
      // try streak shield before breaking streak
      const monthKey = state.lastResetDate.slice(0, 7);
      const shieldUsedThisMonth = state.streak.shieldUsedDate && state.streak.shieldUsedDate.slice(0,7) === monthKey;
      if (state.streak.shieldAvailable && !shieldUsedThisMonth && state.streak.current > 0) {
        state.streak.shieldUsedDate = today;
        state.streak.shieldAvailable = false;
        notify("STREAK SHIELD USED", "Your streak was protected.");
      } else {
        if (state.streak.current > 0) notify("STREAK BROKEN", "A new journey begins.");
        state.streak.current = 0;
      }
    }
    // refresh monthly shield
    if (today.slice(0,7) !== state.lastResetDate.slice(0,7)) {
      state.streak.shieldAvailable = true;
    }

    state.quests = state.quests.map(q => ({ ...q, done: false, date: today }));
    state.lastResetDate = today;
    notify("DAILY RESET", "New quests await.");
    save();
  }
}

/* ---------- achievements ---------- */
const ACHIEVEMENT_DEFS = [
  { id: "first_quest", name: "First Steps", desc: "Complete your first quest.", secret: false,
    check: s => s.quests.some(q => q.done) },
  { id: "streak_7", name: "Week Warrior", desc: "Reach a 7-day streak.", secret: false,
    check: s => s.streak.best >= 7 },
  { id: "streak_30", name: "Iron Will", desc: "Reach a 30-day streak.", secret: false,
    check: s => s.streak.best >= 30 },
  { id: "level_10", name: "Rising Hunter", desc: "Reach Level 10.", secret: false,
    check: s => s.profile.level >= 10 },
  { id: "level_35", name: "Rank A", desc: "Reach Level 35.", secret: false,
    check: s => s.profile.level >= 35 },
  { id: "goal_complete", name: "Goal Getter", desc: "Complete a goal.", secret: false,
    check: s => s.goals.some(g => g.progress >= 100) },
  { id: "notes_10", name: "Archivist", desc: "Create 10 notes.", secret: false,
    check: s => s.notes.length >= 10 },
  { id: "budget_saver", name: "Golden Vault", desc: "Reach a saving goal.", secret: false,
    check: s => s.savingGoals.some(g => g.saved >= g.target && g.target > 0) },
  { id: "quest_100", name: "Centurion", desc: "Complete 100 quests total.", secret: false,
    check: s => s.xpHistory.filter(h => h.amount > 0).length >= 100 },
  { id: "midnight_grind", name: "Midnight Grind", desc: "???", secret: true,
    check: s => new Date().getHours() >= 0 && new Date().getHours() < 4 && s.quests.some(q => q.done) },
];

function checkAchievements() {
  for (const def of ACHIEVEMENT_DEFS) {
    if (!state.achievements[def.id] && def.check(state)) {
      state.achievements[def.id] = { unlockedAt: todayStr() };
      notify("ACHIEVEMENT UNLOCKED", def.name);
    }
  }
  save();
}

/* ---------- daily bonus reward ---------- */
function claimDailyBonus() {
  const today = todayStr();
  if (state.rewardsClaimed[today]) {
    notify("ALREADY CLAIMED", "Come back tomorrow.");
    return false;
  }
  const bonus = 15 + Math.floor(Math.random() * 20);
  state.rewardsClaimed[today] = bonus;
  grantXP(bonus);
  notify("DAILY BONUS", `+${bonus} XP claimed`);
  save();
  return true;
}

function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str ?? "";
  return div.innerHTML;
}

function allSkills() {
  return [...SKILLS, ...(state.profile.customSkills || [])];
}
