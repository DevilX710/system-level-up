/* =========================================================
   NOTES
   ========================================================= */

function addNote(title, body) {
  state.notes.unshift({ id: uid(), title, body, pinned: false, updatedAt: todayStr() });
  save();
  renderNotes();
}

function updateNote(id, title, body) {
  const n = state.notes.find(n => n.id === id);
  if (!n) return;
  n.title = title;
  n.body = body;
  n.updatedAt = todayStr();
  save();
  renderNotes();
}

function deleteNote(id) {
  state.notes = state.notes.filter(n => n.id !== id);
  save();
  renderNotes();
}

function togglePinNote(id) {
  const n = state.notes.find(n => n.id === id);
  if (!n) return;
  n.pinned = !n.pinned;
  save();
  renderNotes();
}

function searchNotes(query) {
  const q = query.trim().toLowerCase();
  let list = state.notes;
  if (q) {
    list = list.filter(n =>
      n.title.toLowerCase().includes(q) || n.body.toLowerCase().includes(q));
  }
  return [...list].sort((a, b) => (b.pinned - a.pinned) || (b.updatedAt.localeCompare(a.updatedAt)));
}
