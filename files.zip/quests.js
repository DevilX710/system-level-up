/* =========================================================
   QUESTS, STREAK, REMINDERS
   ========================================================= */

function addQuest(title, xp, skill) {
  state.quests.push({ id: uid(), title, xp, done: false, date: todayStr(), skill: skill || null });
  save();
  renderQuests();
}

function deleteQuest(id) {
  state.quests = state.quests.filter(q => q.id !== id);
  save();
  renderQuests();
  renderStats();
}

function toggleQuest(id) {
  const q = state.quests.find(q => q.id === id);
  if (!q) return;

  if (!q.done) {
    q.done = true;
    grantXP(q.xp, q.skill);
    updateStreakOnCompletion();
    notify("QUEST COMPLETE", `+${q.xp} XP · ${q.title}`);
    playSound("complete");
  } else {
    q.done = false;
    grantXP(-q.xp, q.skill ? null : null); // don't reverse skillXP to keep history simple
  }
  save();
  renderQuests();
  renderStats();
  renderProfile();
  renderCalendar();
}

function updateStreakOnCompletion() {
  const today = todayStr();
  if (state.streak.lastCompletionDate === today) return;
  state.streak.current += 1;
  state.streak.lastCompletionDate = today;
  if (state.streak.current > state.streak.best) state.streak.best = state.streak.current;
  if (state.streak.current > 0 && state.streak.current % 7 === 0) {
    notify("STREAK MILESTONE", `${state.streak.current} days in a row!`);
  }
}

/* ---------- reminders ---------- */
function addReminder(title, datetime, repeat) {
  state.reminders.push({ id: uid(), title, datetime, repeat: repeat || "none", done: false });
  save();
  renderReminders();
}

function deleteReminder(id) {
  state.reminders = state.reminders.filter(r => r.id !== id);
  save();
  renderReminders();
}

function toggleReminderDone(id) {
  const r = state.reminders.find(r => r.id === id);
  if (!r) return;
  r.done = !r.done;
  save();
  renderReminders();
}

function upcomingReminders() {
  const now = new Date();
  return state.reminders
    .filter(r => !r.done)
    .sort((a, b) => new Date(a.datetime) - new Date(b.datetime));
}

function checkDueReminders() {
  const now = new Date();
  for (const r of state.reminders) {
    if (r.done) continue;
    const dt = new Date(r.datetime);
    if (dt <= now && !r._notified) {
      notify("REMINDER", r.title);
      r._notified = true;
      if (r.repeat === "daily") {
        const next = new Date(dt); next.setDate(next.getDate() + 1);
        r.datetime = next.toISOString().slice(0,16);
        delete r._notified;
      } else if (r.repeat === "weekly") {
        const next = new Date(dt); next.setDate(next.getDate() + 7);
        r.datetime = next.toISOString().slice(0,16);
        delete r._notified;
      }
    }
  }
  save();
}
setInterval(checkDueReminders, 60000); // check every minute while app is open
