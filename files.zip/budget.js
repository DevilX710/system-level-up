/* =========================================================
   BUDGET
   ========================================================= */

const EXPENSE_CATEGORIES = ["Food", "Transport", "Housing", "Fun", "Bills", "Health", "Other"];
const INCOME_CATEGORIES = ["Salary", "Gift", "Side Hustle", "Other"];

function addTransaction(type, amount, category, note) {
  state.transactions.push({
    id: uid(), type, amount: Math.abs(amount), category, note: note || "", date: todayStr(),
  });
  save();
  renderBudget();
  checkAchievements();
}

function deleteTransaction(id) {
  state.transactions = state.transactions.filter(t => t.id !== id);
  save();
  renderBudget();
}

function getBalance() {
  return state.transactions.reduce((sum, t) =>
    sum + (t.type === "income" ? t.amount : -t.amount), 0);
}

function getMonthSummary(monthKey = todayStr().slice(0,7)) {
  const txs = state.transactions.filter(t => t.date.slice(0,7) === monthKey);
  const income = txs.filter(t => t.type === "income").reduce((s,t) => s + t.amount, 0);
  const expense = txs.filter(t => t.type === "expense").reduce((s,t) => s + t.amount, 0);
  const byCategory = {};
  txs.filter(t => t.type === "expense").forEach(t => {
    byCategory[t.category] = (byCategory[t.category] || 0) + t.amount;
  });
  return { income, expense, net: income - expense, byCategory, count: txs.length };
}

/* ---------- saving goals ---------- */
function addSavingGoal(title, target) {
  state.savingGoals.push({ id: uid(), title, target: Number(target) || 0, saved: 0 });
  save();
  renderBudget();
}

function addToSavingGoal(id, amount) {
  const g = state.savingGoals.find(g => g.id === id);
  if (!g) return;
  const wasComplete = g.saved >= g.target;
  g.saved += Number(amount) || 0;
  if (!wasComplete && g.saved >= g.target && g.target > 0) {
    grantXP(40);
    notify("SAVING GOAL REACHED", `${g.title} — +40 XP`);
  }
  save();
  renderBudget();
}

function deleteSavingGoal(id) {
  state.savingGoals = state.savingGoals.filter(g => g.id !== id);
  save();
  renderBudget();
}
