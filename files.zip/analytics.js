/* =========================================================
   ANALYTICS
   ========================================================= */

function xpByDay(days = 14) {
  const out = [];
  for (let i = days - 1; i >= 0; i--) {
    const d = todayStr(-i);
    const total = state.xpHistory
      .filter(h => h.date === d)
      .reduce((s, h) => s + h.amount, 0);
    out.push({ date: d, xp: Math.max(0, total) });
  }
  return out;
}

function questCompletionRate(days = 7) {
  let done = 0, total = 0;
  // approximate using xpHistory positive entries as completions per day present in quests today
  const cutoff = todayStr(-(days - 1));
  const relevant = state.xpHistory.filter(h => h.date >= cutoff && h.amount > 0);
  done = relevant.length;
  total = Math.max(done, state.quests.length * days); // rough denom for a %, avoids /0
  return total === 0 ? 0 : Math.round((done / total) * 100);
}

function weeklySpending() {
  const cutoff = todayStr(-6);
  return state.transactions
    .filter(t => t.type === "expense" && t.date >= cutoff)
    .reduce((s, t) => s + t.amount, 0);
}

/* =========================================================
   CALENDAR
   ========================================================= */

function eventsForDate(dateStr) {
  return {
    quests: state.quests.filter(q => q.date === dateStr),
    reminders: state.reminders.filter(r => r.datetime && r.datetime.startsWith(dateStr)),
    goalsDue: state.goals.filter(g => g.deadline === dateStr),
    completed: state.quests.filter(q => q.date === dateStr).length > 0 &&
               state.quests.filter(q => q.date === dateStr).every(q => q.done),
  };
}

function daysInMonth(year, month) {
  return new Date(year, month + 1, 0).getDate();
}

/* =========================================================
   BACKUP / IMPORT / EXPORT
   ========================================================= */

function exportData() {
  const blob = new Blob([JSON.stringify(state, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = `awakening-backup-${todayStr()}.json`;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
  notify("EXPORTED", "Backup file downloaded");
}

function importData(file, onDone) {
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const parsed = JSON.parse(reader.result);
      state = { ...defaultState(), ...parsed };
      save();
      notify("IMPORTED", "Data restored");
      if (onDone) onDone(true);
    } catch (e) {
      notify("IMPORT FAILED", "Invalid backup file");
      if (onDone) onDone(false);
    }
  };
  reader.readAsText(file);
}

function resetAllData() {
  state = defaultState();
  save();
  notify("SYSTEM RESET", "All data cleared");
}
